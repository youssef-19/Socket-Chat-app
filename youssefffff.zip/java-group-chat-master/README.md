# java-group-chat
this app need to open port 5000 to java socket for server only

------------------------------
My youtube : https://www.youtube.com/watch?v=QfUREEp0kRk
<br/><br/>
![2021-06-21_204422](https://user-images.githubusercontent.com/58245926/122772372-810c5900-d2d1-11eb-83cf-c85a5dd74d94.png)
